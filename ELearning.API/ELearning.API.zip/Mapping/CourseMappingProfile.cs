using AutoMapper;
using ELearning.API.DTOs.Course;
using ELearning.Core.Domain;

namespace ELearning.API.Mapping
{
    public class CourseMappingProfile : Profile
    {
        public CourseMappingProfile()
        {
            CreateMap<Course, CourseDto>()
                .ForMember(dest => dest.InstructorName, opt => opt.MapFrom(src => src.Instructor!.Name))
                .ForMember(dest => dest.AverageRating, opt => opt.MapFrom(src => 
                    src.Reviews.Any() ? src.Reviews.Average(r => r.Rating) : 0))
                .ForMember(dest => dest.ReviewCount, opt => opt.MapFrom(src => src.Reviews.Count))
                .ForMember(dest => dest.EnrolledStudentsCount, opt => opt.MapFrom(src => src.EnrolledStudents.Count));

            CreateMap<Category, CategoryDto>();

            CreateMap<Module, ModuleDto>()
                .ForMember(dest => dest.LessonCount, opt => opt.MapFrom(src => src.Lessons.Count));

            CreateMap<Lesson, LessonDto>();

            CreateMap<Assignment, AssignmentDto>()
                .ForMember(dest => dest.SubmissionCount, opt => opt.MapFrom(src => src.Submissions.Count));

            CreateMap<Quiz, QuizDto>()
                .ForMember(dest => dest.QuestionCount, opt => opt.MapFrom(src => src.Questions.Count));

            CreateMap<Question, QuestionDto>();

            CreateMap<Option, OptionDto>();

            CreateMap<Submission, SubmissionDto>()
                .ForMember(dest => dest.StudentName, opt => opt.MapFrom(src => src.Student!.Name));

            CreateMap<Resource, ResourceDto>();

            CreateMap<Review, ReviewDto>()
                .ForMember(dest => dest.StudentName, opt => opt.MapFrom(src => src.Student!.Name));
        }
    }
} 