using ELearning.API.DTOs.Lesson;
using ELearning.API.DTOs.Progress;
using ELearning.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ELearning.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LessonController : ControllerBase
    {
        private readonly ILessonService _lessonService;

        public LessonController(ILessonService lessonService)
        {
            _lessonService = lessonService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<LessonDto>>> GetAllLessons()
        {
            var lessons = await _lessonService.GetAllLessonsAsync();
            return Ok(lessons);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<LessonDto>> GetLessonById(Guid id)
        {
            var lesson = await _lessonService.GetLessonByIdAsync(id);
            if (lesson == null)
            {
                return NotFound();
            }
            return Ok(lesson);
        }

        [HttpPost]
        [Authorize(Roles = "Instructor")]
        public async Task<ActionResult<LessonDto>> CreateLesson(CreateLessonDto createLessonDto)
        {
            var lesson = await _lessonService.CreateLessonAsync(createLessonDto);
            return CreatedAtAction(nameof(GetLessonById), new { id = lesson.Id }, lesson);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Instructor")]
        public async Task<ActionResult<LessonDto>> UpdateLesson(Guid id, UpdateLessonDto updateLessonDto)
        {
            try
            {
                var lesson = await _lessonService.UpdateLessonAsync(id, updateLessonDto);
                return Ok(lesson);
            }
            catch (InvalidOperationException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Instructor")]
        public async Task<IActionResult> DeleteLesson(Guid id)
        {
            try
            {
                await _lessonService.DeleteLessonAsync(id);
                return NoContent();
            }
            catch (InvalidOperationException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpGet("module/{moduleId}")]
        public async Task<ActionResult<IEnumerable<LessonDto>>> GetModuleLessons(Guid moduleId)
        {
            var lessons = await _lessonService.GetModuleLessonsAsync(moduleId);
            return Ok(lessons);
        }

        [HttpPost("{lessonId}/complete/{studentId}")]
        [Authorize(Roles = "Student")]
        public async Task<ActionResult<ProgressDto>> MarkLessonAsCompleted(Guid lessonId, Guid studentId)
        {
            try
            {
                var progress = await _lessonService.MarkLessonAsCompletedAsync(lessonId, studentId);
                return Ok(progress);
            }
            catch (InvalidOperationException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPut("{lessonId}/progress/{studentId}")]
        [Authorize(Roles = "Student")]
        public async Task<ActionResult<ProgressDto>> UpdateLessonProgress(Guid lessonId, Guid studentId, [FromBody] int timeSpent)
        {
            try
            {
                var progress = await _lessonService.UpdateLessonProgressAsync(lessonId, studentId, timeSpent);
                return Ok(progress);
            }
            catch (InvalidOperationException ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
} 