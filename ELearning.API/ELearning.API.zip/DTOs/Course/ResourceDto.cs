using ELearning.Core.Domain;

namespace ELearning.API.DTOs.Course
{
    public class ResourceDto
    {
        public Guid Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public ResourceType Type { get; set; }
        public string? Url { get; set; }
        public Guid? LessonId { get; set; }
        public Guid? ModuleId { get; set; }
    }
} 