namespace ELearning.API.DTOs.Course
{
    public class SubmissionDto
    {
        public Guid Id { get; set; }
        public string Content { get; set; } = string.Empty;
        public string? FileUrl { get; set; }
        public DateTime SubmittedAt { get; set; }
        public int? Score { get; set; }
        public string? Feedback { get; set; }
        public Guid AssignmentId { get; set; }
        public Guid StudentId { get; set; }
        public string StudentName { get; set; } = string.Empty;
    }
} 