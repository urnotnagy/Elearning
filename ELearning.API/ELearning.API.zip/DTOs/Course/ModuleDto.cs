namespace ELearning.API.DTOs.Course
{
    public class ModuleDto
    {
        public Guid Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int Order { get; set; }
        public Guid CourseId { get; set; }
        public List<LessonDto> Lessons { get; set; } = new();
        public List<AssignmentDto> Assignments { get; set; } = new();
        public List<QuizDto> Quizzes { get; set; } = new();
        public int LessonCount { get; set; }
    }
} 