using System.ComponentModel.DataAnnotations;
using ELearning.Core.Domain;

namespace ELearning.API.DTOs.Course
{
    public class CreateCourseDto
    {
        [Required]
        [MinLength(3)]
        public string Title { get; set; } = string.Empty;

        [Required]
        public string Description { get; set; } = string.Empty;

        [Required]
        [Range(0, 10000)]
        public decimal Price { get; set; }

        public string? ImageUrl { get; set; }
        public int DurationInWeeks { get; set; }
        public CourseLevel Level { get; set; }
        public List<Guid> CategoryIds { get; set; } = new();
    }
} 