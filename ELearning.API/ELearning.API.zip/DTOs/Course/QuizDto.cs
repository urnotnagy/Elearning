namespace ELearning.API.DTOs.Course
{
    public class QuizDto
    {
        public Guid Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime DueDate { get; set; }
        public int TimeLimit { get; set; }
        public int MaxAttempts { get; set; }
        public int PassingScore { get; set; }
        public Guid ModuleId { get; set; }
        public Guid? UserId { get; set; }
        public List<QuestionDto> Questions { get; set; } = new();
        public int QuestionCount { get; set; }
    }
} 