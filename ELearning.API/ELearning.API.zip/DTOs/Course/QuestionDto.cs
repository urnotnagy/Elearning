using ELearning.Core.Domain;

namespace ELearning.API.DTOs.Course
{
    public class QuestionDto
    {
        public Guid Id { get; set; }
        public string Text { get; set; } = string.Empty;
        public QuestionType Type { get; set; }
        public int Points { get; set; }
        public Guid QuizId { get; set; }
        public List<OptionDto> Options { get; set; } = new();
    }
} 