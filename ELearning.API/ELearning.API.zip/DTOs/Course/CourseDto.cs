using ELearning.Core.Domain;

namespace ELearning.API.DTOs.Course
{
    public class CourseDto
    {
        public Guid Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public string? ImageUrl { get; set; }
        public int DurationInWeeks { get; set; }
        public CourseLevel Level { get; set; }
        public CourseStatus Status { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public Guid InstructorId { get; set; }
        public string InstructorName { get; set; } = string.Empty;
        public List<CategoryDto> Categories { get; set; } = new();
        public List<ModuleDto> Modules { get; set; } = new();
        public List<ReviewDto> Reviews { get; set; } = new();
        public double AverageRating { get; set; }
        public int ReviewCount { get; set; }
        public int EnrolledStudentsCount { get; set; }
    }
} 