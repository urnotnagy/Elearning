using System.ComponentModel.DataAnnotations;

namespace ELearning.API.DTOs.Module
{
    public class CreateModuleDto
    {
        [Required]
        [MinLength(3)]
        public string Title { get; set; } = string.Empty;

        [Required]
        public string Description { get; set; } = string.Empty;

        [Required]
        [Range(0, int.MaxValue)]
        public int Order { get; set; }

        [Required]
        public Guid CourseId { get; set; }
    }
} 