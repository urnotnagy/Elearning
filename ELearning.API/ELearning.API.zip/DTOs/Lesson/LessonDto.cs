using ELearning.API.DTOs.Course;
using ELearning.API.DTOs.Progress;

namespace ELearning.API.DTOs.Lesson
{
    public class LessonDto
    {
        public Guid Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public string? VideoUrl { get; set; }
        public int Order { get; set; }
        public int DurationInMinutes { get; set; }
        public Guid ModuleId { get; set; }
        public List<ResourceDto> Resources { get; set; } = new();
        public List<ProgressDto> StudentProgress { get; set; } = new();
    }
} 