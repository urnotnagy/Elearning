using System.ComponentModel.DataAnnotations;

namespace ELearning.API.DTOs.Lesson
{
    public class UpdateLessonDto
    {
        [Required]
        [MinLength(3)]
        public string Title { get; set; } = string.Empty;

        [Required]
        public string Description { get; set; } = string.Empty;

        [Required]
        public string Content { get; set; } = string.Empty;

        public string? VideoUrl { get; set; }

        [Required]
        [Range(0, int.MaxValue)]
        public int Order { get; set; }

        [Required]
        [Range(1, 480)] // 8 hours max
        public int DurationInMinutes { get; set; }
    }
} 