using System;
using System.Collections.Generic;
using ELearning.Core.Common;

namespace ELearning.Core.Domain
{
    public class User : BaseEntity
    {
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Name => $"{FirstName} {LastName}";
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string? PhoneNumber { get; set; }
        public string? ProfilePictureUrl { get; set; }
        public string? Bio { get; set; }
        public UserRole Role { get; set; }
        public bool IsActive { get; set; }
        public DateTime? LastLoginAt { get; set; }

        // Navigation properties
        public virtual ICollection<Course> InstructedCourses { get; set; }
        public virtual ICollection<Course> EnrolledCourses { get; set; }
        public virtual ICollection<Assignment> Assignments { get; set; }
        public virtual ICollection<Submission> Submissions { get; set; }
        public virtual ICollection<Quiz> Quizzes { get; set; }
        public virtual ICollection<QuizAttempt> QuizAttempts { get; set; }
        public virtual ICollection<Review> Reviews { get; set; }
        public virtual ICollection<Progress> LessonProgress { get; set; }

        public User()
        {
            InstructedCourses = new HashSet<Course>();
            EnrolledCourses = new HashSet<Course>();
            Assignments = new HashSet<Assignment>();
            Submissions = new HashSet<Submission>();
            Quizzes = new HashSet<Quiz>();
            QuizAttempts = new HashSet<QuizAttempt>();
            Reviews = new HashSet<Review>();
            LessonProgress = new HashSet<Progress>();
        }
    }

    public enum UserRole
    {
        Student,
        Instructor,
        Admin
    }
} 