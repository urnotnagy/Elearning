using System;
using System.Collections.Generic;
using ELearning.Core.Common;

namespace ELearning.Core.Domain
{
    public class Course : BaseEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string ImageUrl { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public int DurationInWeeks { get; set; }
        public CourseLevel Level { get; set; }
        public CourseStatus Status { get; set; }
        public Guid InstructorId { get; set; }
        public virtual User? Instructor { get; set; }

        // Navigation properties
        public virtual ICollection<Module> Modules { get; set; }
        public virtual ICollection<User> EnrolledStudents { get; set; }
        public virtual ICollection<Category> Categories { get; set; }
        public virtual ICollection<Review> Reviews { get; set; }

        public Course()
        {
            Modules = new HashSet<Module>();
            EnrolledStudents = new HashSet<User>();
            Categories = new HashSet<Category>();
            Reviews = new HashSet<Review>();
        }
    }

    public enum CourseLevel
    {
        Beginner,
        Intermediate,
        Advanced,
        Expert
    }

    public enum CourseStatus
    {
        Draft,
        Published,
        Archived
    }
} 