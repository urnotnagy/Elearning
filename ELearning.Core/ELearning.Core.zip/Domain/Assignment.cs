using System;
using System.Collections.Generic;
using ELearning.Core.Common;

namespace ELearning.Core.Domain
{
    public class Assignment : BaseEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime DueDate { get; set; }
        public int MaxScore { get; set; }
        public Guid ModuleId { get; set; }
        public virtual Module? Module { get; set; }

        // Navigation properties
        public virtual ICollection<Submission> Submissions { get; set; }

        public Assignment()
        {
            Submissions = new HashSet<Submission>();
        }
    }
} 