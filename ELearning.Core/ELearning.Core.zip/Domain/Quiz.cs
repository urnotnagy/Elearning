using System;
using System.Collections.Generic;
using ELearning.Core.Common;

namespace ELearning.Core.Domain
{
    public class Quiz : BaseEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int TimeLimit { get; set; } // in minutes
        public int PassingScore { get; set; }
        public int MaxAttempts { get; set; }
        public DateTime DueDate { get; set; }
        public Guid ModuleId { get; set; }
        public virtual Module? Module { get; set; }

        // Navigation properties
        public virtual ICollection<Question> Questions { get; set; }
        public virtual ICollection<QuizAttempt> Attempts { get; set; }

        public Quiz()
        {
            Questions = new HashSet<Question>();
            Attempts = new HashSet<QuizAttempt>();
        }
    }
}