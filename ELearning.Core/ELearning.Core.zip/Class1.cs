﻿namespace ELearning.Core;

public class Class1
{

}
