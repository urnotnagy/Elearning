﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace ELearning.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class SeedData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "CreatedAt", "Description", "IconUrl", "IsDeleted", "Name", "ParentCategoryId", "UpdatedAt" },
                values: new object[,]
                {
                    { new Guid("773539d6-737a-4963-aab5-24de691e45a0"), new DateTime(2025, 4, 1, 12, 35, 7, 229, DateTimeKind.Utc).AddTicks(5348), "Programming courses", "", false, "Programming", null, null },
                    { new Guid("c633ee79-ea0e-4a5b-b73b-0c84d432e726"), new DateTime(2025, 4, 1, 12, 35, 7, 229, DateTimeKind.Utc).AddTicks(5356), "Design courses", "", false, "Design", null, null }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Bio", "CreatedAt", "Email", "FirstName", "IsActive", "IsDeleted", "LastLoginAt", "LastName", "PasswordHash", "PhoneNumber", "ProfilePictureUrl", "Role", "UpdatedAt" },
                values: new object[,]
                {
                    { new Guid("779074c9-7eee-4288-94a7-403ac27635a5"), null, new DateTime(2025, 4, 1, 12, 35, 7, 17, DateTimeKind.Utc).AddTicks(2481), "instructor@elearning.com", "John", false, false, null, "Doe", "$2a$11$iz5YT8Eyg3kApvQ3fbkmO.wFWXkT2aRMe8wQuCOBXwe6fou6KvAkW", null, null, 1, null },
                    { new Guid("7bfbb6b5-d077-4127-b079-120afda0ff79"), null, new DateTime(2025, 4, 1, 12, 35, 6, 802, DateTimeKind.Utc).AddTicks(3136), "admin@elearning.com", "Admin", false, false, null, "User", "$2a$11$PktTWc4IpC7IP05Fln7bjOiqAFpubwPAGAxVPyLb8DxCbRzqvDRaO", null, null, 2, null },
                    { new Guid("ee906747-f76b-47fc-8697-686f8629160e"), null, new DateTime(2025, 4, 1, 12, 35, 7, 229, DateTimeKind.Utc).AddTicks(3787), "student@elearning.com", "Jane", false, false, null, "Smith", "$2a$11$Ek5SL898ppuSXlYJWfrEveqnPZnW1tMALE54zlXsFjVkT.nghajce", null, null, 0, null }
                });

            migrationBuilder.InsertData(
                table: "Courses",
                columns: new[] { "Id", "CreatedAt", "Description", "DurationInWeeks", "ImageUrl", "InstructorId", "IsDeleted", "Level", "Price", "Status", "Title", "UpdatedAt" },
                values: new object[] { new Guid("3f5d53f6-27f9-4ff6-9823-d3bd7b6a9e63"), new DateTime(2025, 4, 1, 12, 35, 7, 229, DateTimeKind.Utc).AddTicks(5519), "Learn the basics of C# programming", 0, "", new Guid("779074c9-7eee-4288-94a7-403ac27635a5"), false, 0, 49.99m, 0, "Introduction to C#", null });

            migrationBuilder.InsertData(
                table: "CategoryCourse",
                columns: new[] { "CategoriesId", "CoursesId" },
                values: new object[] { new Guid("773539d6-737a-4963-aab5-24de691e45a0"), new Guid("3f5d53f6-27f9-4ff6-9823-d3bd7b6a9e63") });

            migrationBuilder.InsertData(
                table: "CourseUser",
                columns: new[] { "EnrolledCoursesId", "EnrolledStudentsId" },
                values: new object[] { new Guid("3f5d53f6-27f9-4ff6-9823-d3bd7b6a9e63"), new Guid("ee906747-f76b-47fc-8697-686f8629160e") });

            migrationBuilder.InsertData(
                table: "Modules",
                columns: new[] { "Id", "CourseId", "CreatedAt", "Description", "IsDeleted", "Order", "Title", "UpdatedAt" },
                values: new object[] { new Guid("efe477ff-c4d3-4723-b1be-4e5216be9a8f"), new Guid("3f5d53f6-27f9-4ff6-9823-d3bd7b6a9e63"), new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(779), "Basic concepts and setup", false, 1, "Getting Started with C#", null });

            migrationBuilder.InsertData(
                table: "Reviews",
                columns: new[] { "Id", "Comment", "CourseId", "CreatedAt", "IsDeleted", "Rating", "StudentId", "UpdatedAt" },
                values: new object[] { new Guid("4a337daf-87f0-4c8c-a0b3-d29819d7c3cf"), "Great course for beginners!", new Guid("3f5d53f6-27f9-4ff6-9823-d3bd7b6a9e63"), new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(1634), false, 5, new Guid("ee906747-f76b-47fc-8697-686f8629160e"), null });

            migrationBuilder.InsertData(
                table: "Assignments",
                columns: new[] { "Id", "CreatedAt", "Description", "DueDate", "IsDeleted", "MaxScore", "ModuleId", "Title", "UpdatedAt", "UserId" },
                values: new object[] { new Guid("e28aabe7-b6cf-4f7f-bb6f-64dfd6b9f22b"), new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(1114), "Create your first C# program", new DateTime(2025, 4, 8, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(1075), false, 0, new Guid("efe477ff-c4d3-4723-b1be-4e5216be9a8f"), "First C# Program", null, null });

            migrationBuilder.InsertData(
                table: "Lessons",
                columns: new[] { "Id", "Content", "CreatedAt", "Description", "DurationInMinutes", "IsDeleted", "ModuleId", "Order", "Title", "UpdatedAt", "VideoUrl" },
                values: new object[] { new Guid("2c0441df-c2be-4b39-a65f-8048924e89de"), "C# is a modern, object-oriented programming language...", new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(942), "", 0, false, new Guid("efe477ff-c4d3-4723-b1be-4e5216be9a8f"), 1, "Introduction to C#", null, null });

            migrationBuilder.InsertData(
                table: "Quizzes",
                columns: new[] { "Id", "CreatedAt", "Description", "DueDate", "IsDeleted", "MaxAttempts", "ModuleId", "PassingScore", "TimeLimit", "Title", "UpdatedAt", "UserId" },
                values: new object[] { new Guid("83967d63-7a86-44df-80e1-b29185ccc73c"), new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(1280), "Test your knowledge of C# basics", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), false, 0, new Guid("efe477ff-c4d3-4723-b1be-4e5216be9a8f"), 0, 30, "C# Basics Quiz", null, null });

            migrationBuilder.InsertData(
                table: "Progresses",
                columns: new[] { "Id", "CompletedAt", "CreatedAt", "IsCompleted", "IsDeleted", "LessonId", "StudentId", "TimeSpent", "UpdatedAt" },
                values: new object[] { new Guid("a5b7a871-048d-44bb-ae4c-19d7b88a31fe"), new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(2273), new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(2278), true, false, new Guid("2c0441df-c2be-4b39-a65f-8048924e89de"), new Guid("ee906747-f76b-47fc-8697-686f8629160e"), 0, null });

            migrationBuilder.InsertData(
                table: "Questions",
                columns: new[] { "Id", "CreatedAt", "IsDeleted", "Points", "QuizId", "Text", "Type", "UpdatedAt" },
                values: new object[] { new Guid("b69a8240-4910-4fd1-a42a-22c477c662a0"), new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(1406), false, 1, new Guid("83967d63-7a86-44df-80e1-b29185ccc73c"), "What is C#?", 0, null });

            migrationBuilder.InsertData(
                table: "Resources",
                columns: new[] { "Id", "CreatedAt", "Description", "IsDeleted", "LessonId", "ModuleId", "Title", "Type", "UpdatedAt", "Url" },
                values: new object[] { new Guid("d1b66979-7d3e-4590-9c5a-680636cc5058"), new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(2050), "Official C# documentation", false, new Guid("2c0441df-c2be-4b39-a65f-8048924e89de"), null, "C# Documentation", 3, null, "https://docs.microsoft.com/en-us/dotnet/csharp/" });

            migrationBuilder.InsertData(
                table: "Options",
                columns: new[] { "Id", "CreatedAt", "IsCorrect", "IsDeleted", "QuestionId", "Text", "UpdatedAt" },
                values: new object[,]
                {
                    { new Guid("9654167c-5cab-4ff0-9cd5-798f4e43e815"), new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(1547), false, false, new Guid("b69a8240-4910-4fd1-a42a-22c477c662a0"), "A database", null },
                    { new Guid("a3047bab-1d6e-496e-b8e9-2f6d4fb78086"), new DateTime(2025, 4, 1, 12, 35, 7, 230, DateTimeKind.Utc).AddTicks(1541), true, false, new Guid("b69a8240-4910-4fd1-a42a-22c477c662a0"), "A programming language", null }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Assignments",
                keyColumn: "Id",
                keyValue: new Guid("e28aabe7-b6cf-4f7f-bb6f-64dfd6b9f22b"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("c633ee79-ea0e-4a5b-b73b-0c84d432e726"));

            migrationBuilder.DeleteData(
                table: "CategoryCourse",
                keyColumns: new[] { "CategoriesId", "CoursesId" },
                keyValues: new object[] { new Guid("773539d6-737a-4963-aab5-24de691e45a0"), new Guid("3f5d53f6-27f9-4ff6-9823-d3bd7b6a9e63") });

            migrationBuilder.DeleteData(
                table: "CourseUser",
                keyColumns: new[] { "EnrolledCoursesId", "EnrolledStudentsId" },
                keyValues: new object[] { new Guid("3f5d53f6-27f9-4ff6-9823-d3bd7b6a9e63"), new Guid("ee906747-f76b-47fc-8697-686f8629160e") });

            migrationBuilder.DeleteData(
                table: "Options",
                keyColumn: "Id",
                keyValue: new Guid("9654167c-5cab-4ff0-9cd5-798f4e43e815"));

            migrationBuilder.DeleteData(
                table: "Options",
                keyColumn: "Id",
                keyValue: new Guid("a3047bab-1d6e-496e-b8e9-2f6d4fb78086"));

            migrationBuilder.DeleteData(
                table: "Progresses",
                keyColumn: "Id",
                keyValue: new Guid("a5b7a871-048d-44bb-ae4c-19d7b88a31fe"));

            migrationBuilder.DeleteData(
                table: "Resources",
                keyColumn: "Id",
                keyValue: new Guid("d1b66979-7d3e-4590-9c5a-680636cc5058"));

            migrationBuilder.DeleteData(
                table: "Reviews",
                keyColumn: "Id",
                keyValue: new Guid("4a337daf-87f0-4c8c-a0b3-d29819d7c3cf"));

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("7bfbb6b5-d077-4127-b079-120afda0ff79"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("773539d6-737a-4963-aab5-24de691e45a0"));

            migrationBuilder.DeleteData(
                table: "Lessons",
                keyColumn: "Id",
                keyValue: new Guid("2c0441df-c2be-4b39-a65f-8048924e89de"));

            migrationBuilder.DeleteData(
                table: "Questions",
                keyColumn: "Id",
                keyValue: new Guid("b69a8240-4910-4fd1-a42a-22c477c662a0"));

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("ee906747-f76b-47fc-8697-686f8629160e"));

            migrationBuilder.DeleteData(
                table: "Quizzes",
                keyColumn: "Id",
                keyValue: new Guid("83967d63-7a86-44df-80e1-b29185ccc73c"));

            migrationBuilder.DeleteData(
                table: "Modules",
                keyColumn: "Id",
                keyValue: new Guid("efe477ff-c4d3-4723-b1be-4e5216be9a8f"));

            migrationBuilder.DeleteData(
                table: "Courses",
                keyColumn: "Id",
                keyValue: new Guid("3f5d53f6-27f9-4ff6-9823-d3bd7b6a9e63"));

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("779074c9-7eee-4288-94a7-403ac27635a5"));
        }
    }
}
