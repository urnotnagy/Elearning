﻿namespace ELearning.Infrastructure;

public class Class1
{

}
