using ELearning.Core.Domain;
using Microsoft.EntityFrameworkCore;

namespace ELearning.Infrastructure.Data
{
    public static class SeedData
    {
        public static void Initialize(ModelBuilder modelBuilder)
        {
            // Seed Users
            var admin = new User
            {
                Id = Guid.NewGuid(),
                Email = "admin@elearning.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin123!"),
                FirstName = "Admin",
                LastName = "User",
                Role = UserRole.Admin,
                CreatedAt = DateTime.UtcNow
            };

            var instructor = new User
            {
                Id = Guid.NewGuid(),
                Email = "instructor@elearning.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("Instructor123!"),
                FirstName = "John",
                LastName = "Doe",
                Role = UserRole.Instructor,
                CreatedAt = DateTime.UtcNow
            };

            var student = new User
            {
                Id = Guid.NewGuid(),
                Email = "student@elearning.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("Student123!"),
                FirstName = "Jane",
                LastName = "Smith",
                Role = UserRole.Student,
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<User>().HasData(admin, instructor, student);

            // Seed Categories
            var programming = new Category
            {
                Id = Guid.NewGuid(),
                Name = "Programming",
                Description = "Programming courses",
                CreatedAt = DateTime.UtcNow
            };

            var design = new Category
            {
                Id = Guid.NewGuid(),
                Name = "Design",
                Description = "Design courses",
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<Category>().HasData(programming, design);

            // Seed Course
            var course = new Course
            {
                Id = Guid.NewGuid(),
                Title = "Introduction to C#",
                Description = "Learn the basics of C# programming",
                InstructorId = instructor.Id,
                Price = 49.99m,
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<Course>().HasData(course);

            // Seed Course-Category relationship
            modelBuilder.Entity<Course>()
                .HasMany(c => c.Categories)
                .WithMany(c => c.Courses)
                .UsingEntity(j => j.HasData(
                    new { CoursesId = course.Id, CategoriesId = programming.Id }
                ));

            // Seed Course-Student relationship
            modelBuilder.Entity<Course>()
                .HasMany(c => c.EnrolledStudents)
                .WithMany(u => u.EnrolledCourses)
                .UsingEntity(j => j.HasData(
                    new { EnrolledStudentsId = student.Id, EnrolledCoursesId = course.Id }
                ));

            // Seed Module
            var module = new Module
            {
                Id = Guid.NewGuid(),
                Title = "Getting Started with C#",
                Description = "Basic concepts and setup",
                CourseId = course.Id,
                Order = 1,
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<Module>().HasData(module);

            // Seed Lesson
            var lesson = new Lesson
            {
                Id = Guid.NewGuid(),
                Title = "Introduction to C#",
                Content = "C# is a modern, object-oriented programming language...",
                ModuleId = module.Id,
                Order = 1,
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<Lesson>().HasData(lesson);

            // Seed Assignment
            var assignment = new Assignment
            {
                Id = Guid.NewGuid(),
                Title = "First C# Program",
                Description = "Create your first C# program",
                ModuleId = module.Id,
                DueDate = DateTime.UtcNow.AddDays(7),
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<Assignment>().HasData(assignment);

            // Seed Quiz
            var quiz = new Quiz
            {
                Id = Guid.NewGuid(),
                Title = "C# Basics Quiz",
                Description = "Test your knowledge of C# basics",
                ModuleId = module.Id,
                TimeLimit = 30,
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<Quiz>().HasData(quiz);

            // Seed Question
            var question = new Question
            {
                Id = Guid.NewGuid(),
                Text = "What is C#?",
                Type = QuestionType.MultipleChoice,
                QuizId = quiz.Id,
                Points = 1,
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<Question>().HasData(question);

            // Seed Options
            var options = new[]
            {
                new Option
                {
                    Id = Guid.NewGuid(),
                    Text = "A programming language",
                    IsCorrect = true,
                    QuestionId = question.Id,
                    CreatedAt = DateTime.UtcNow
                },
                new Option
                {
                    Id = Guid.NewGuid(),
                    Text = "A database",
                    IsCorrect = false,
                    QuestionId = question.Id,
                    CreatedAt = DateTime.UtcNow
                }
            };

            modelBuilder.Entity<Option>().HasData(options);

            // Seed Review
            var review = new Review
            {
                Id = Guid.NewGuid(),
                Rating = 5,
                Comment = "Great course for beginners!",
                CourseId = course.Id,
                StudentId = student.Id,
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<Review>().HasData(review);

            // Seed Resource
            var resource = new Resource
            {
                Id = Guid.NewGuid(),
                Title = "C# Documentation",
                Description = "Official C# documentation",
                Type = ResourceType.Link,
                Url = "https://docs.microsoft.com/en-us/dotnet/csharp/",
                LessonId = lesson.Id,
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<Resource>().HasData(resource);

            // Seed Progress
            var progress = new Progress
            {
                Id = Guid.NewGuid(),
                LessonId = lesson.Id,
                StudentId = student.Id,
                IsCompleted = true,
                CompletedAt = DateTime.UtcNow,
                CreatedAt = DateTime.UtcNow
            };

            modelBuilder.Entity<Progress>().HasData(progress);
        }
    }
} 